# CAT IN WW2 EDITOR — Native Android app

This is a **native Android app**, not a website locked inside a WebView. The screens are implemented with Android views and reproduce the current creator hub's content and dark/gold visual theme.

## What is included

- Home/hero section with “MEMES. ON REPEAT.” branding
- Working **Watch Edits**, **Copy Channel Link**, and **Subscribe** actions
- Edit-category cards for regular edits, memes/Shorts, and AMVs
- About section and footer
- Links open through Android's normal app chooser/link handling (YouTube app when available, otherwise the browser)
- Custom launcher icon in the website's dark/gold palette
- No embedded browser, no in-app address bar, and no single-site lock

## Build the APK without Android Studio

A GitHub Actions workflow is included. It compiles the APK on GitHub's cloud runners, so Android Studio is not needed on your phone or computer.

1. Download and extract this ZIP.
2. Create a new repository on GitHub (a free account is enough). Name it `cat-in-ww2-editor-android`.
3. Upload the **contents** of the extracted folder to the repository's `main` branch, keeping the folder structure. In particular, keep `.github/workflows/build-apk.yml` in that exact path. GitHub's web uploader may hide dot-folders in some file pickers; if so, enable viewing hidden files or upload the source using GitHub's web editor.
4. Open the repository's **Actions** tab. Select **Build CAT IN WW2 EDITOR APK** and press **Run workflow**. If the Actions tab asks to enable workflows, enable them.
5. When the run finishes successfully, open that run and download the artifact named `CAT-IN-WW2-EDITOR-APK`.
6. Extract the downloaded artifact ZIP. It contains `CAT-IN-WW2-EDITOR.apk`. Transfer it to your Android phone and tap it to install. Android may ask you to allow installs from the app you used to open the file.

This workflow makes a **debug APK** for testing and personal installation. It is not a Play Store release-signed APK. Do not share signing keys or passwords in a public repository.

## Project details

- Package: `com.catinww2editor.app`
- App label: `CAT IN WW2 EDITOR`
- Minimum Android: 6.0 (API 23)
- Website reference: `https://cat-in-ww2-editor-qbkjmx.v2.appdeploy.ai/`
- YouTube channel: `https://www.youtube.com/@catinww2editor`

## Important limitation

The project source is written and the cloud build workflow is included, but this environment has no Android SDK/Gradle installation and cannot reach Google's SDK download servers. Therefore an APK has **not** been compiled or tested here. The GitHub Actions workflow is the build step.
