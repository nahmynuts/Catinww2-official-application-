package com.catinww2editor.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PathEffect;
import android.graphics.DashPathEffect;
import android.graphics.Typeface;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String CHANNEL = "https://www.youtube.com/@catinww2editor";
    private static final String VIDEOS = "https://www.youtube.com/@catinww2editor/videos";
    private static final String SHORTS = "https://www.youtube.com/@catinww2editor/shorts";
    private static final int BG = Color.rgb(16, 17, 15);
    private static final int PANEL = Color.rgb(21, 22, 18);
    private static final int CARD = Color.rgb(26, 27, 23);
    private static final int GOLD = Color.rgb(212, 179, 106);
    private static final int TEXT = Color.rgb(236, 233, 223);
    private static final int MUTED = Color.rgb(150, 152, 142);
    private ScrollView scroller;
    private LinearLayout page;
    private View watchSection;
    private View aboutSection;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);

        scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(BG);
        scroller.setClipToPadding(false);
        scroller.setVerticalScrollBarEnabled(false);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(BG);
        scroller.addView(page, new ScrollView.LayoutParams(-1, -2));

        page.addView(buildTopbar());
        page.addView(buildHero());
        page.addView(buildTicker());
        watchSection = buildWatchSection();
        page.addView(watchSection);
        aboutSection = buildAboutSection();
        page.addView(aboutSection);
        page.addView(buildFooter());
        setContentView(scroller);
    }

    private View buildTopbar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(20), dp(14), dp(20), dp(14));
        bar.setBackgroundColor(BG);

        TextView mark = text("✧", 25, GOLD, Typeface.BOLD);
        mark.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.TRANSPARENT);
        circle.setStroke(dp(1), 0x66D4B36A);
        mark.setBackground(circle);
        LinearLayout.LayoutParams markLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        markLp.rightMargin = dp(11);
        bar.addView(mark, markLp);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView name = text("CAT IN WW2 EDITOR", 14, TEXT, Typeface.create("sans-serif-condensed", Typeface.BOLD));
        name.setLetterSpacing(0.08f);
        TextView tagline = text("MEMES · AMV · EDITS", 9, MUTED, Typeface.create("monospace", Typeface.NORMAL));
        tagline.setLetterSpacing(0.09f);
        LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(-2, -2);
        tagLp.topMargin = dp(3);
        brand.addView(name);
        brand.addView(tagline, tagLp);
        bar.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView subscribe = text("SUBSCRIBE ↗", 10, GOLD, Typeface.create("monospace", Typeface.BOLD));
        subscribe.setGravity(Gravity.CENTER);
        subscribe.setPadding(dp(10), dp(12), dp(10), dp(12));
        subscribe.setBackground(borderDrawable(0x00D4B36A, 0x88D4B36A, 0));
        subscribe.setOnClickListener(v -> openExternal(CHANNEL));
        bar.addView(subscribe);
        View line = new View(this);
        line.setBackgroundColor(0x22FFFFFF);
        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        holder.addView(bar);
        holder.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        return holder;
    }

    private View buildHero() {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(23), dp(39), dp(23), dp(25));
        hero.setBackgroundColor(BG);

        LinearLayout eyebrow = new LinearLayout(this);
        eyebrow.setOrientation(LinearLayout.HORIZONTAL);
        eyebrow.setGravity(Gravity.CENTER_VERTICAL);
        TextView dot = text("●", 8, GOLD, Typeface.DEFAULT_BOLD);
        eyebrow.addView(dot, new LinearLayout.LayoutParams(-2, -2));
        TextView eyetext = text("  MEMES · AMV · GENERAL EDITS", 10, GOLD, Typeface.create("monospace", Typeface.NORMAL));
        eyetext.setLetterSpacing(0.05f);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-2, -2);
        ep.leftMargin = dp(6);
        eyebrow.addView(eyetext, ep);
        hero.addView(eyebrow);

        TextView title1 = text("MEMES.", 64, TEXT, Typeface.create("sans-serif-condensed", Typeface.BOLD));
        title1.setLetterSpacing(-0.035f);
        LinearLayout.LayoutParams t1 = new LinearLayout.LayoutParams(-1, -2);
        t1.topMargin = dp(25);
        hero.addView(title1, t1);
        TextView title2 = text("ON REPEAT.", 61, GOLD, Typeface.create("sans-serif-condensed", Typeface.BOLD));
        title2.setLetterSpacing(-0.035f);
        hero.addView(title2);

        TextView subtitle = text("AMVs, meme edits, and regular edits — all in one place.", 15, TEXT, Typeface.create("sans-serif", Typeface.BOLD));
        subtitle.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams sublp = new LinearLayout.LayoutParams(-1, -2);
        sublp.topMargin = dp(19);
        hero.addView(subtitle, sublp);
        TextView desc = text("Welcome to the edit zone for @catinww2editor. Catch the vibe, find your next favourite edit, and explore the latest uploads.", 13, MUTED, Typeface.create("sans-serif", Typeface.NORMAL));
        desc.setLineSpacing(dp(5), 1.15f);
        LinearLayout.LayoutParams desclp = new LinearLayout.LayoutParams(-1, -2);
        desclp.topMargin = dp(10);
        hero.addView(desc, desclp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams actsLp = new LinearLayout.LayoutParams(-1, -2);
        actsLp.topMargin = dp(22);
        hero.addView(actions, actsLp);
        TextView watch = actionButton("▶  WATCH EDITS  ↗", true);
        watch.setOnClickListener(v -> openExternal(VIDEOS));
        actions.addView(watch, new LinearLayout.LayoutParams(-1, dp(50)));
        TextView copy = actionButton("▣  COPY CHANNEL LINK", false);
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(-1, dp(50));
        copyLp.topMargin = dp(10);
        actions.addView(copy, copyLp);
        copy.setOnClickListener(v -> copyChannelLink());

        TextView note = text("◇  CREATOR HUB · YOUTUBE OPENS IN ITS OWN APP", 9, 0xFF77796F, Typeface.create("monospace", Typeface.NORMAL));
        note.setLetterSpacing(0.02f);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = dp(18);
        hero.addView(note, noteLp);

        AbstractArt art = new AbstractArt(this);
        LinearLayout.LayoutParams artLp = new LinearLayout.LayoutParams(-1, dp(245));
        artLp.topMargin = dp(12);
        hero.addView(art, artLp);
        TextView index = text("01  /  THE EDIT ZONE", 9, 0xFF6B6D62, Typeface.create("monospace", Typeface.NORMAL));
        index.setGravity(Gravity.RIGHT);
        hero.addView(index);
        return hero;
    }

    private View buildTicker() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setFillViewport(false);
        hsv.setBackgroundColor(GOLD);
        LinearLayout ticker = new LinearLayout(this);
        ticker.setGravity(Gravity.CENTER_VERTICAL);
        ticker.setOrientation(LinearLayout.HORIZONTAL);
        ticker.setPadding(dp(16), dp(16), dp(16), dp(16));
        String[] labels = {"MEME EDITS", "✳", "AMV ENERGY", "✳", "BEAT SYNC", "✳", "EDITS ON REPEAT", "✳"};
        for (int i = 0; i < labels.length; i++) {
            TextView part = text(labels[i], i % 2 == 0 ? 11 : 14, BG,
                    Typeface.create("sans-serif-condensed", i % 2 == 0 ? Typeface.BOLD : Typeface.NORMAL));
            part.setLetterSpacing(i % 2 == 0 ? 0.12f : 0f);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
            if (i > 0) p.leftMargin = dp(20);
            ticker.addView(part, p);
        }
        hsv.addView(ticker);
        return hsv;
    }

    private View buildWatchSection() {
        LinearLayout section = new LinearLayout(this);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setPadding(dp(22), dp(38), dp(22), dp(40));
        section.setBackgroundColor(PANEL);

        TextView eyebrow = text("THE EDIT PLAYLIST / 01", 10, GOLD, Typeface.create("monospace", Typeface.NORMAL));
        eyebrow.setLetterSpacing(0.07f);
        section.addView(eyebrow);
        TextView heading = text("PICK YOUR VIBE.", 39, TEXT, Typeface.create("sans-serif-condensed", Typeface.BOLD));
        LinearLayout.LayoutParams h = new LinearLayout.LayoutParams(-1, -2);
        h.topMargin = dp(9);
        section.addView(heading, h);
        TextView count = text("CHANNEL ACCESS // 03", 9, 0xFF6C6F65, Typeface.create("monospace", Typeface.NORMAL));
        LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(-1, -2);
        c.topMargin = dp(5);
        c.bottomMargin = dp(22);
        section.addView(count, c);

        section.addView(watchCard("REGULAR EDITS", "Find the latest edits on the main channel feed.", "01 / NORMAL EDITS", "NEW CUTS HERE", 0, VIDEOS));
        section.addView(watchCard("Meme edits & Shorts", "Quick edits, memes, and short videos.", "02 / MEMES & SHORTS", "QUICK CUTS", 1, SHORTS), cardGap());
        section.addView(watchCard("AMVs & more", "Open the channel and explore every edit.", "03 / AMV ZONE", "MEMES · AMV · EDITS", 2, CHANNEL), cardGap());

        TextView note = text("◉  These links open YouTube directly, where you can catch the latest memes, AMVs, and other edits.", 10, 0xFF77796F, Typeface.create("monospace", Typeface.NORMAL));
        note.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = dp(20);
        section.addView(note, np);
        return section;
    }

    private LinearLayout.LayoutParams cardGap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(15);
        return lp;
    }

    private View watchCard(String title, String detail, String tag, String corner, int style, String url) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(borderDrawable(CARD, 0x20FFFFFF, 0));
        card.setClipToOutline(true);
        CardArt art = new CardArt(this, style, tag, corner);
        card.addView(art, new LinearLayout.LayoutParams(-1, dp(185)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.HORIZONTAL);
        info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(15), dp(16), dp(15), dp(16));
        TextView name = text(title, 20, TEXT, Typeface.create("sans-serif-condensed", Typeface.BOLD));
        TextView descr = text(detail, 11, MUTED, Typeface.create("sans-serif", Typeface.NORMAL));
        descr.setLineSpacing(dp(3), 1f);
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(name);
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(-1, -2);
        dp2.topMargin = dp(5);
        labels.addView(descr, dp2);
        info.addView(labels, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView arrow = text("↗", 22, GOLD, Typeface.NORMAL);
        arrow.setGravity(Gravity.CENTER);
        arrow.setBackground(borderDrawable(Color.TRANSPARENT, 0x44FFFFFF, 1));
        info.addView(arrow, new LinearLayout.LayoutParams(dp(36), dp(36)));
        card.addView(info);
        card.setOnClickListener(v -> openExternal(url));
        card.setClickable(true);
        card.setFocusable(true);
        return card;
    }

    private View buildAboutSection() {
        LinearLayout section = new LinearLayout(this);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setPadding(dp(22), dp(38), dp(22), dp(40));
        section.setBackgroundColor(BG);

        LinearLayout symbol = new LinearLayout(this);
        symbol.setOrientation(LinearLayout.VERTICAL);
        symbol.setGravity(Gravity.CENTER);
        symbol.setPadding(dp(18), dp(20), dp(18), dp(20));
        symbol.setBackground(borderDrawable(Color.TRANSPARENT, 0x55D4B36A, 0));
        TextView globe = text("◎", 36, GOLD, Typeface.NORMAL);
        globe.setGravity(Gravity.CENTER);
        symbol.addView(globe);
        TextView est = text("EST. ONLINE", 8, MUTED, Typeface.create("monospace", Typeface.NORMAL));
        est.setLetterSpacing(0.1f);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-2, -2);
        elp.topMargin = dp(7);
        symbol.addView(est, elp);
        TextView identity = text("MEMES\n& AMVS", 26, GOLD, Typeface.create("sans-serif-condensed", Typeface.BOLD));
        identity.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
        ilp.topMargin = dp(12);
        symbol.addView(identity, ilp);
        section.addView(symbol, new LinearLayout.LayoutParams(dp(150), -2));

        TextView eyebrow = text("CREATOR BRIEF / 02", 10, GOLD, Typeface.create("monospace", Typeface.NORMAL));
        eyebrow.setLetterSpacing(0.06f);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = dp(27);
        section.addView(eyebrow, ep);
        TextView heading = text("YOUR FAVOURITE VIBES.\nFRESH EDITS.", 34, TEXT, Typeface.create("sans-serif-condensed", Typeface.BOLD));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(12);
        section.addView(heading, hp);
        TextView desc = text("This hub is built around the edits shared by CAT IN WW2 EDITOR. Browse meme edits, AMVs, and other video edits, check out Shorts, and support the channel on YouTube.", 12, MUTED, Typeface.create("sans-serif", Typeface.NORMAL));
        desc.setLineSpacing(dp(4), 1.1f);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, -2);
        dlp.topMargin = dp(14);
        section.addView(desc, dlp);
        TextView enter = text("ENTER THE EDIT ZONE   ↗", 10, GOLD, Typeface.create("monospace", Typeface.BOLD));
        enter.setLetterSpacing(0.03f);
        LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(-2, dp(42));
        el.topMargin = dp(12);
        section.addView(enter, el);
        enter.setOnClickListener(v -> openExternal(CHANNEL));
        return section;
    }

    private View buildFooter() {
        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setPadding(dp(22), dp(22), dp(22), dp(24));
        footer.setBackgroundColor(BG);
        View line = new View(this);
        line.setBackgroundColor(0x22FFFFFF);
        footer.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        TextView brand = text("◎  CAT IN WW2 EDITOR", 12, TEXT, Typeface.create("sans-serif-condensed", Typeface.BOLD));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = dp(19);
        footer.addView(brand, bp);
        TextView tagline = text("MADE FOR THE EDIT-LOVING COMMUNITY.", 9, 0xFF77796F, Typeface.create("monospace", Typeface.NORMAL));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, -2);
        tlp.topMargin = dp(10);
        footer.addView(tagline, tlp);
        TextView open = text("OPEN YOUTUBE  ↗", 10, GOLD, Typeface.create("monospace", Typeface.BOLD));
        LinearLayout.LayoutParams olp = new LinearLayout.LayoutParams(-1, dp(42));
        olp.topMargin = dp(15);
        footer.addView(open, olp);
        open.setOnClickListener(v -> openExternal(CHANNEL));
        return footer;
    }

    private TextView actionButton(String label, boolean primary) {
        TextView button = text(label, 11, primary ? BG : TEXT, Typeface.create("monospace", Typeface.BOLD));
        button.setGravity(Gravity.CENTER);
        button.setLetterSpacing(0.025f);
        button.setBackground(borderDrawable(primary ? GOLD : Color.TRANSPARENT, primary ? GOLD : 0x44FFFFFF, 0));
        button.setClickable(true);
        button.setFocusable(true);
        return button;
    }

    private TextView text(String value, float sizeSp, int color, Typeface face) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sizeSp);
        v.setTextColor(color);
        v.setTypeface(face);
        v.setIncludeFontPadding(true);
        return v;
    }

    private GradientDrawable borderDrawable(int color, int strokeColor, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        if (radiusDp > 0) d.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private void copyChannelLink() {
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("YouTube channel", CHANNEL));
            Toast.makeText(this, "Channel link copied", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            Toast.makeText(this, "Could not copy the link", Toast.LENGTH_SHORT).show();
        }
    }

    private void openExternal(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(intent);
        } catch (Exception ex) {
            Toast.makeText(this, "No app available to open this link", Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private class AbstractArt extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        AbstractArt(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight();
            float cx = w * .5f, cy = h * .49f, r = Math.min(w * .38f, h * .42f);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(0x55D4B36A);
            c.drawCircle(cx, cy, r, p);
            p.setColor(0x44D4B36A); p.setPathEffect(new DashPathEffect(new float[]{dp(5),dp(5)}, 0));
            c.drawCircle(cx, cy, r*.82f, p); p.setPathEffect(null);
            p.setColor(0x66D4B36A); c.drawCircle(cx, cy, r*.60f, p);
            p.setColor(0x22D4B36A); c.drawLine(cx-r*.86f, cy, cx+r*.86f, cy, p); c.drawLine(cx, cy-r*.86f, cx, cy+r*.86f, p);
            p.setStyle(Paint.Style.FILL); p.setColor(GOLD); p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(58));
            c.drawText("AMV", cx, cy+dp(19), p);
            p.setTypeface(Typeface.create("monospace", Typeface.NORMAL)); p.setTextSize(dp(8)); p.setColor(0xFFE0C783);
            c.drawText("CUT / SYNC / REPLAY", cx, cy-r*.80f, p);
            c.drawText("MADE TO HIT DIFFERENT", cx, cy+r*.82f, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); p.setColor(GOLD);
            RectF stamp = new RectF(cx+r*.46f, cy+r*.42f, cx+r*.97f, cy+r*.78f);
            c.save(); c.rotate(8, stamp.centerX(), stamp.centerY()); c.drawRect(stamp,p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(dp(11));
            c.drawText("EDIT", stamp.centerX(), stamp.centerY(), p); c.drawText("MODE", stamp.centerX(), stamp.centerY()+dp(10), p); c.restore();
        }
    }

    private class CardArt extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int style;
        private final String tag, corner;
        CardArt(Context c, int style, String tag, String corner) { super(c); this.style=style; this.tag=tag; this.corner=corner; }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            int bg1 = style==1 ? Color.rgb(48,32,25) : (style==2 ? Color.rgb(30,32,26) : Color.rgb(38,39,31));
            p.setShader(new LinearGradient(0,0,w,h,bg1,BG,Shader.TileMode.CLAMP)); c.drawRect(0,0,w,h,p); p.setShader(null);
            p.setStrokeWidth(dp(1)); p.setStyle(Paint.Style.STROKE);
            if (style==0) {
                p.setColor(0x18D4B36A);
                for(float x=0; x<w; x+=dp(24)) c.drawLine(x,0,x,h,p);
                for(float y=0; y<h; y+=dp(24)) c.drawLine(0,y,w,y,p);
            } else if(style==1) {
                p.setColor(0x22D9A078);
                for(float i=-h;i<w;i+=dp(20)) c.drawLine(i,0,i+h,h,p);
            } else {
                p.setColor(0x44D4B36A); c.drawCircle(w/2,h/2,Math.min(w,h)*.26f,p); p.setPathEffect(new DashPathEffect(new float[]{dp(4),dp(5)},0)); c.drawCircle(w/2,h/2,Math.min(w,h)*.40f,p); p.setPathEffect(null);
            }
            p.setStyle(Paint.Style.FILL); p.setColor(GOLD); p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.create("monospace",Typeface.NORMAL)); p.setTextSize(dp(8)); c.drawText(tag,dp(14),dp(20),p);
            p.setTextAlign(Paint.Align.RIGHT); p.setColor(0xFFC2B58E); c.drawText(corner,w-dp(14),h-dp(13),p);
            p.setTextAlign(Paint.Align.CENTER); p.setColor(GOLD); p.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD)); p.setTextSize(dp(42));
            if(style==0) {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); c.drawCircle(w/2,h/2,dp(31),p); p.setStyle(Paint.Style.FILL); p.setTextSize(dp(26)); c.drawText("▶",w/2+dp(1),h/2+dp(10),p);
            } else if(style==1) {
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1)); c.drawRoundRect(new RectF(w/2-dp(28),h/2-dp(28),w/2+dp(28),h/2+dp(28)),dp(12),dp(12),p); p.setStyle(Paint.Style.FILL); p.setTextSize(dp(36)); c.drawText("ϟ",w/2,h/2+dp(13),p);
            } else { p.setTextSize(dp(39)); c.drawText("▶",w/2,h/2+dp(14),p); }
            p.setStyle(Paint.Style.FILL);
        }
    }
}
